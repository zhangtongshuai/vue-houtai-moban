import axios from 'axios';

const service = axios.create({
    baseURL: 'http://192.168.3.4:8080/jeecg-boot',
    timeout: 5000
});

service.interceptors.request.use( config => {
    console.log('1111111111-----------');
    console.log(config);
    return config;
}, error => {
    console.log(error);
    console.log('2222222222222-----------');
    return Promise.reject();
});

service.interceptors.response.use(response => {
    console.log('3333333-----------');
    console.log(response);
    if(response.status === 200){
        console.log('44444444-----------');
        return response.data;
    }else{
        console.log('555555555-----------');
        Promise.reject();
    }
}, error => {
    console.log('666666666-----------');
    console.log(error);
    return Promise.reject();
});


//返回一个Promise(发送post请求)
export function fetchPost(url, params) {
    return new Promise((resolve, reject) => {
        service.post(url, params)
            .then(response => {
                resolve(response);
            }, err => {
                reject(err);
            })
            .catch((error) => {
                reject(error)
            })
    })
}

////返回一个Promise(发送get请求)
export function fetchGet(url, param) {
    return new Promise((resolve, reject) => {
        service.get(url, {params: param})
            .then(response => {
                resolve(response)
            }, err => {
                reject(err)
            })
            .catch((error) => {
                reject(error)
            })
    })
}

export default {
    fetchPost,
    fetchGet,
}
